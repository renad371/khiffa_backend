<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('statuses')->insert([
            'status' => 'order_accepted',
        ]);
        DB::table('statuses')->insert([
            'status' => 'arrived_at_service_provider_location',
        ]);
        DB::table('statuses')->insert([
            'status' => 'order_received_from_service_provider',
        ]);
        DB::table('statuses')->insert([
            'status' => 'arrived_at_beneficiary_location',
        ]);
        DB::table('statuses')->insert([
            'status' => 'order_delivered',
        ]);
    }
}
