<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AttachmentTypes extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('attachment_types')->insert([
            'type' => 'user_portrait', // user portrait/photogragh
        ]);
        DB::table('attachment_types')->insert([
            'type' => 'user_license', // user driver license 
        ]);
        DB::table('attachment_types')->insert([
            'type' => 'user_car', // user car picture
        ]);
        // DB::table('attachment_types')->insert([
        //     'type' => 'serpro_logo', // service provider logo
        // ]);
    }
}
