<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class StatusTypes extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      //Account
        DB::table('status_types')->insert([
            'status' => 'Suspended',
        ]);
        DB::table('status_types')->insert([
            'status' => 'Active',
        ]);
        DB::table('status_types')->insert([
            'status' => 'Inactive',
        ]);

        DB::table('status_types')->insert([
            'status' => 'in progress',
        ]);
        //ticket
        DB::table('status_types')->insert([
            'status' => 'Pending',
        ]);
        DB::table('status_types')->insert([
            'status' => 'Open',
        ]);
        DB::table('status_types')->insert([
            'status' => 'Under Review',
        ]);
        DB::table('status_types')->insert([
            'status' => 'Closed',
        ]);
       //attachment
       DB::table('status_types')->insert([
        'status' => 'Current',
    ]);
       DB::table('status_types')->insert([
        'status' => 'Perverse',
    ]);
       DB::table('status_types')->insert([
        'status' => 'Latest',
    ]);
    }
}
