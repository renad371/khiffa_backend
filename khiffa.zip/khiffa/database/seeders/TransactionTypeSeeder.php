<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransactionTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //wallet deposit
        DB::table('transaction_types')->insert([
            'type' => 'w-depo',
        ]);
        //wallet withdraw
        DB::table('transaction_types')->insert([
            'type' => 'w-widr',
        ]);
        //bank deposit
        DB::table('transaction_types')->insert([
            'type' => 'b-depo',
        ]);
    }
}
