<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('khiffa_id')->unique();
            $table->double('delivery_cost');
            $table->double('distance');
            $table->foreignId('company_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->foreignId('service_provider_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->foreignId('receipt_id')
            ->nullable()
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->foreignId('user_id')
            ->nullable()
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->foreignId('beneficiary_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->foreignId('address_id') // {{not final}} just trying it out. NOTE: this is the beneficiary's address
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
};
