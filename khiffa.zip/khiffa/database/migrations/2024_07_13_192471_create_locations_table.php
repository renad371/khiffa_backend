<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locations', function (Blueprint $table) {
            $table->id();
            $table->double('x'); //not sure
            $table->double('y'); //not sure
            $table->string('Polygon');
            $table->foreignId ('location_type_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->foreignId ('order_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locations');
    }
};
