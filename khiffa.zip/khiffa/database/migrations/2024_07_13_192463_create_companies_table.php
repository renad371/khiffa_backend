<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->id();
            $table->string('company_token')
            ->nullable()
            ->unique();
            $table->string('company_name')->unique();
            $table->string('arabic_name')->unique();
            $table->string('company_domain')->unique()
            ->nullable()
            ->unique();
            $table->string('khiffa_token')->unique()
            ->nullable()
            ->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
};
