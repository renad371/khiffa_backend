<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('service_providers', function (Blueprint $table) {
            $table->id();
            $table->string('khiffa_id')->unique();
            $table->string('name');
            $table->double('location_x'); //not sure
            $table->double('location_y'); //not sure
            $table->string('polygon'); // new addition
            $table->string('path'); // new addition
            $table->foreignId('address_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade'); //not sure
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('service_providers');
    }
};
