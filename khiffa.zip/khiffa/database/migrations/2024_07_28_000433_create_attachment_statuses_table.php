<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attachment_statuses', function (Blueprint $table) {
            $table->id();
            $table->foreignId ('attachment_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade');
            $table->foreignId ('status_type_id')
            ->constrained()
            ->onUpdate('cascade')
            ->onDelete('cascade');
            $table->unique(['attachment_id','status_type_id']);
            $table->timestamps();
            $table->text('description')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attachment_statuses');
    }
};
