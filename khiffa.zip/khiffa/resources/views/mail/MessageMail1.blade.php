
Dear {{$name}}

We would like to inform you that the status of your order has been updated.

You can track the details of your order through your account on our website. If you have any questions or need further assistance, please do not hesitate to contact our customer service team.

Thank you for choosing Khiffa.

Best regards,
The Khiffa Team