<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ServiceProviderController;
use App\Http\Controllers\TransactionController;
use App\Mail\OtpMail;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
route::post('registerAdmin',[AdminController::class,'registerAdmin']);
//--------------------------------------Dashboard ----------------------------------------- 

Route::get('countServiceProvidersByCompany',[DashboardController::class,'countServiceProvidersByCompany']);

Route::get('minDate',[DashboardController::class,'minDate']);

Route::get('countOrderByCompany',[DashboardController::class,'countOrderByCompany']);

Route::get('countAllOrder',[DashboardController::class,'countAllOrder']);

Route::get('Timeline',[DashboardController::class,'Timeline']);

Route::get('countDelivery',[DashboardController::class,'countDelivery']);

Route::get('dashboard',[DashboardController::class,'index'])->middleware('auth:sanctum');

//-------------------------------------admin------------------------------------------------

Route::get('users',[AdminController::class,'Deliveries'])->middleware('auth:sanctum');

Route::post('changeAccountStatus',[AdminController::class,'changeAccountStatus'])->middleware('auth:sanctum');

// Route::get('users',[AdminController::class,'index'])->middleware('auth:sanctum');

Route::get('accountRequests',[AdminController::class,'accountRequests'])->middleware('auth:sanctum');

Route::get('showManagementDeliveries',[AdminController::class,'showManagementDeliveries'])->middleware('auth:sanctum');

Route::get('showInfoAccountReq',[AdminController::class,'showInfoAccountReq'])->middleware('auth:sanctum');

Route::get('paginatingTicket',[AdminController::class,'paginatingTicket'])->middleware('auth:sanctum');

Route::get('showTicket',[AdminController::class,'showTicket'])->middleware('auth:sanctum');

//---------------------------------Transactions----------------------------------------------
Route::get('showTransactions',[TransactionController::class,'showTransactions'])->middleware('auth:sanctum');

Route::post('sendTransactions',[TransactionController::class,'sendTransactions'])->middleware('auth:sanctum');

Route::get('paginatingLsTrsn',[AdminController::class,'paginatingLsTrsn'])->middleware('auth:sanctum');

Route::get('walletAdmin',[AdminController::class,'wallet'])->middleware('auth:sanctum');

//---------------------------------ticket-----------------------------------------------------

Route::get('ticketStatuses',[TicketController::class,'ticketStatuses'])->middleware('auth:sanctum');

Route::get('countAllTicket',[TicketController::class,'countAllTicket'])->middleware('auth:sanctum');


// ----------------------------------------------testing-----------------------------------------------
Route::post('users/reject',[AdminController::class,'rejectionDescription'])->middleware('auth:sanctum');