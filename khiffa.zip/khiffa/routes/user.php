<?php
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ServiceProviderController;
use App\Http\Controllers\TransactionController;
use App\Mail\OtpMail;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

//----------------------------Account-----------------------------
Route::post('register',[UserController::class,'store']);

Route::put('profile/update',[UserController::class,'update'])->middleware('auth:sanctum');

Route::post('login/reset',[UserController::class,'resetPass']);

Route::post('login',[UserController::class,'login']);

Route::post('logout',[UserController::class,'logout'])->middleware('auth:sanctum');

Route::post('profile/delete',[UserController::class,'delete'])->middleware('auth:sanctum');

Route::post('profile/update-attachments',[UserController::class,'updateOnReject'])->middleware('auth:sanctum');

route::get('profile',[UserController::class,'profileInformation'])->middleware('auth:sanctum');

route::put('orders/city',[UserController::class,'updateCity'])->middleware('auth:sanctum');

//----------------------Tickets-------------------------------------
Route::post('tickets',[TicketController::class,'store'])->middleware('auth:sanctum');

Route::get('tickets',[UserController::class,'showTicketDel'])->middleware('auth:sanctum');

//---------------------Transactions----------------------------------
Route::post('transactions1',[TransactionController::class,'requestTransactions'])->middleware('auth:sanctum');

//------------------------------tickets------------------------------
Route::post('tickets/status',[TicketController::class,'changeTicketStatus'])->middleware('auth:sanctum');

Route::get('tickets/status',[TicketController::class,'showTicket'])->middleware('auth:sanctum'); // مو المفروض قيت؟

Route::get('tickets/all',[TicketController::class,'showallTicket'])->middleware('auth:sanctum');

Route::get('transactions',[UserController::class,'paginatingLsTrsnDel'])->middleware('auth:sanctum');

Route::get('wallet',[UserController::class,'walletDel'])->middleware('auth:sanctum');
