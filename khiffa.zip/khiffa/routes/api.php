<?php
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ServiceProviderController;
use App\Mail\OtpMail;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');


// -------------------------------company routes----------------------------------------
Route::post('companies',[CompanyController::class,'store']);

Route::get('companies',[CompanyController::class,'index'])->middleware('auth:sanctum');

// -------------------------------service provider routes----------------------------------------
Route::post('service-providers',[ServiceProviderController::class,'store']);

Route::get('service_providers',[ServiceProviderController::class,'index'])->middleware('auth:sanctum');

// -------------------------------order routes----------------------------------------
Route::post('orders',[OrderController::class,'store']);

Route::get('orders',[OrderController::class,'index'])->middleware('auth:sanctum'); //all orders

Route::post('orders/assign',[OrderController::class,'AssignOrder'])->middleware('auth:sanctum');

Route::put('orders/status',[OrderController::class,'updateOrderStatus'])->middleware('auth:sanctum');

Route::get('orders/{id}',[OrderController::class,'show'])->middleware('auth:sanctum');

// attachment
Route::post('profile/attach',[OrderController::class,'store'])->middleware('auth:sanctum'); // still in progress
//
// -------------------------------System routes----------------------------------------

Route::post('send',[UserController::class,'sendOtp']);

Route::post('CheckOtp',[UserController::class,'CheckOtp']);

Route::get('showTransactions',[UserController::class,'showTransactions'])->middleware('auth:sanctum');

Route::post('sendTransactions',[UserController::class,'sendTransactions'])->middleware('auth:sanctum');

