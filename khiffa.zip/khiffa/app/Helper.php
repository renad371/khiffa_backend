<?php

namespace App;

use App\Http\Controllers\HelperController;

class Helper {
    public static function getKhiffaId($company, $id)
    {
        return $company.$id;
    }

    public static function getAttachmentName($id, $national, $name, $type, $version, $extension)
    {
        return $id.$national."-".$name."-".$type."-v".$version.".".$extension;
    }
}