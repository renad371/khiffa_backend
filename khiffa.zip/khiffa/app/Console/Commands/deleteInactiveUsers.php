<?php

namespace App\Console\Commands;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Console\Command;

class deleteInactiveUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:delete-Inactive-Users';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
      //  return Command::SUCCESS;
        $date = Carbon::now()->subMinute(2);

        $user = User::where('email_verified', false)
            //  dd($user);
            ->where('created_at', '<', $date)->delete();

    }
}
