<?php

namespace App\Http\Controllers;

use App\Helper;
use App\Http\Requests\OrderRequest;
use App\Http\Resources\OrderResource;
use App\Http\Resources\OrderStatusResource;
use App\Models\AccountInformation;
use App\Models\Address;
use App\Models\Beneficiary;
use App\Models\Company;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\Receipt;
use App\Models\ServiceProvider;
use App\Models\Status;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

use function Termwind\ask;

class OrderController extends Controller
{
    // // ----------------------------get orders------------------------------- // DONE DONNNNNEEE
    public function index()
    {
        $orders= Order::where('user_id', null)->paginate(6);

        if(auth()->user() == null){
            return OrderResource::collection($orders);
        }
    }

    // --------------------------------filter orders------------------------------
    public function filter(Request $request)
    {
        $registerOrderData = $request->validate([
            'filter_by' => 'bail|nullable|string|in:highest_price,lowest_price,most_distance,least_distance',
            'company' => 'bail|nullable|string'
        ]);

        $company = Company::where('company_name', $request->company)->first();
        //dd($company);

        if(!$registerOrderData){
            return response()->json([
                'message' => 'المعلومات المدخلة غير صحيحة!',
            ],422);
        }

        //price filtering
        if($request->filter_by == "highest_price"){
            $by_price= Order::query()->orderByDesc('delivery_cost')->paginate(6);
            $orders = OrderResource::collection($by_price);
        }else if($request->filter_by == "lowest_price"){
            $by_price= Order::query()->orderBy('delivery_cost')->paginate(6);
            $orders = OrderResource::collection($by_price);
        }
        //distance filtering
        if($request->filter_by == "most_distance"){
            $by_distance= Order::query()->orderByDesc('distance')->paginate(6);
            $orders = OrderResource::collection($by_distance);
        }else if($request->filter_by == "least_distance"){
            $by_distance= Order::query()->orderBy('distance')->paginate(6);
            $orders = OrderResource::collection($by_distance);
        }

        //dd($company);
        //dd($company->id);
        //company
        if($company == null){
            return response()->json($orders,200);
        }else{
            $orders->where('company_id', $company->id)->paginate(6);
        }
    }

    // ------------------------------------store order (coming from other companies)--------------------------------------- // DONE DONNNNNEEE
    public function store(OrderRequest $request)
    {
        //NOTE:: done and tested. ONLY MISSING THE REQUEST VALIDATION
        
        // find the company that sent the request using the company_token
        $company = Company::where('company_token', $request->company_token)->first(); // the company that sent the request

        if($request->company_token == null || $company == null){
            return response()->json([
                "message" => "غير مصرح لك القيام بهذا الإجراء!"
            ],401);
        }

        // try looking for beneficiary
        $beneficiary = Beneficiary::where('phone_number', $request->phone_number)->first();
        if($beneficiary == null){
            // create beneficiary
            $beneficiary = Beneficiary::create([
                'name' => $request->beneficiary_name,
                'phone_number' => $request->phone_number,
            ]);
        }
        // create beneficiary address
        $address = Address::create([
            'city' => $request->beneficiary_city,
            'district' => $request->beneficiary_district,
            'address_type_id' => 2,
        ]);
        $khiffa_id = Helper::getKhiffaId($company->company_name,$request->service_provider_id); // to get the khiffa_id

        $serviceProvider = ServiceProvider::where('khiffa_id', $khiffa_id)->first();

        if($serviceProvider == null){
            $address->delete();
            return response()->json([
                'message' => 'لم تقم بتسجيل مزود الخدمة بعد!',
            ],422);
        }

        $khiffa_id = Helper::getKhiffaId($company->company_name,$request->order_id);
        
        $order = Order::create([
            'khiffa_id' => $khiffa_id,
            'delivery_cost' => $request->delivery_cost, // done
            'distance' => $request->distance, // done
            'company_id' => $company->id, // done
            'service_provider_id' => $serviceProvider->id, // done
            'beneficiary_id' => $beneficiary->id, //done
            'address_id' => $address->id, //done
        ]);

        return response()->json([
            "message" => "تمت إضافة الطلب بنجاح!"
        ],200);
    }

    // ----------------------------------show order----------------------------------- // DONE DONNNNNEEE
    public function show(Request $request)
    {
        $registerOrderData = $request->validate([
            'order_id' => 'required|integer|exists:orders,id',
        ]);
        $order = Order::where('id', $request->order_id)->first();
        $user = User::where('id', auth()->user()->id)->first();
        $khiffa_id = preg_replace("/[^0-9]/", '', $order->khiffa_id);

        if($order->user_id == null){
            return response()->json([

                "order" => new OrderResource($order),
            ],200);
        }

        if($order->user_id == auth()->user()->id){
            return response()->json([
                "order_id" => $khiffa_id,
                "order" => new OrderResource($order),
            ],200);
        }
    }

    // ----------------------------------assign order to user----------------------------------- // DONE DONNNNNEEE
    public function Receipt($transaction){
        // dd($transaction->id);
        $receipts = Receipt::create([
            'transaction_id' => $transaction->id,
        ]);
    }
 
    public function Transactions($wallet,$transaction_type_id){
        $transactions = Transaction::create([
            'price' => $wallet->amount,
            'processed' => 0,
            'wallet_id' => $wallet->id,
            'transaction_type_id' => $transaction_type_id,
        ]);
        return $transactions;
    }

    public function assignOrder(Request $request)
    {
        // DONE. TESTED AND IT WORKS AS EXPECTED!!
        ini_set('max_execution_time', '300');
        $registerOrderData = $request->validate([
            'order_id' => 'required|integer|exists:orders,id',
        ]);
        $order = Order::where('id', $request->order_id)->first();
        $user = User::where('id', auth()->user()->id)->first();
        $userInfo = AccountInformation::where('user_id', $user->id)->first();
        $company = Company::where('id', $order->company_id)->first();

        // dd($userInfo);

        // $anotherOrder = Order::where('user_id', auth()->user()->id)->latest()->first();
        //$orderStatus = OrderStatus::where('order_id', $anotherOrder->id)->latest()->first();

        $status = OrderStatus::whereHas('order',function($q) use ($user){
            $q->where('user_id',$user->id);
        })->latest()->first();

        // if the order had already been assigned to the user
        if($order->user_id == auth()->user()->id){
            // ----------------------------------------------------------------------
            return response()->json([
                "message" => "عذرًا، يتعذر تنفيذ طلبك!",
                "details" => "لقد تم تعيين هذا الطلب إليك بالفعل!"
            ],400);
            // ----------------------------------------------------------------------
        }

        // if the deliverer hasn't delivered the last order he took on, he can't take another order
        if($status && $status->status_id < 5){
            return response()->json([
                "message" => "عذرًا، يتعذر تنفيذ طلبك!",
                "details" => "لم تقم بتسليم الطلب الحالي بعد!"
            ],400);
        }
        
        // if the order is assigned to another user
        if($order->user_id != null && $order->user_id != auth()->user()->id){
            return response()->json([
                "message" => "عذرًا، يتعذر تنفيذ طلبك!",
                "details" => "لقد تم تعيين هذا الطلب إلى مستخدم آخر بالفعل!"
            ],400);
        }

        $order->update([
            'user_id' => $user->id,
        ]);

        OrderStatus::create([
            'status_id' => 1, 
            'order_id' => $order->id,
        ]);
        $wallet = Wallet::where('user_id', $user->id)->first();
        $transactions = $this->Transactions($wallet,1);
        $this->Receipt($transactions);

        // $response = Http::post($company->company_domain.'api/order/update-status', [
        $response = Http::withHeaders([
            'Accept' => 'application/json',
        ])->post('http://192.168.8.170:8000/api/updateDelivery', [
            "order_status" => 1,
            "Delivery_status" => Status::where('id', 1)->first()->status,
            "order_id" => preg_replace("/[^0-9]/", '', $order->khiffa_id),
            "delivery_name" => $userInfo->name,
            "delivery_phone" => $userInfo->phone_number,
            "app_token" => $company->khiffa_token
        ]);

        return response()->json([
            "message" => "تم تعيين الطلب للمستخدم بنجاح!",
        ],200);
    }

    // ----------------------------------update order status----------------------------------- // DONE DONNNNNEEE
    public function updateOrderStatus(Request $request)
    {
        // NOTE:: NOT YET TESTED
        $order = Order::where('id', $request->order_id)->first();
        $user = User::where('id', auth()->user()->id)->first();
        $orderStatus = OrderStatus::where('order_id', $order->id)->latest()->first();
        $userInfo = AccountInformation::where('user_id', $user->id)->first();
        $company = Company::where('id', $order->company_id)->first();
        
        $status = $orderStatus->status_id;
        if($status == 1){
            $thisOrder = OrderStatus::create([
                'status_id' => 2, 
                'order_id' => $order->id,
            ]);
            $response = Http::post($company->company_domain.'api/order/update-status', [
                "order_status" => 2,
                "status_name" => Status::where('id', 2)->first()->status,
                "order_id" => preg_replace("/[^0-9]/", '', $order->khiffa_id),
                "driver_name" => $userInfo->name,
                "driver_phone" => $userInfo->phone_number,
                "access_token" => $company->khiffa_token
            ]);
            return response()->json([
                "message" => "تم تحديث حالة الطلب بنجاح",
                "order" => new OrderStatusResource($thisOrder),
            ],200);
        }else if($status == 2){
            $thisOrder = OrderStatus::create([
                'status_id' => 3, 
                'order_id' => $order->id,
            ]);
            $response = Http::post($company->company_domain.'api/order/update-status', [
                "order_status" => 3,
                "status_name" => Status::where('id', 3)->first()->status,
                "order_id" => preg_replace("/[^0-9]/", '', $order->khiffa_id),
                "driver_name" => $userInfo->name,
                "driver_phone" => $userInfo->phone_number,
                "access_token" => $company->khiffa_token
            ]);
            return response()->json([
                "message" => "تم تحديث حالة الطلب بنجاح",
                "order" => new OrderStatusResource($thisOrder),
            ],200);
        }else if($status == 3){
            $thisOrder = OrderStatus::create([
                'status_id' => 4, 
                'order_id' => $order->id,
            ]);
            $response = Http::post($company->company_domain.'api/order/update-status', [
                "order_status" => 4,
                "status_name" => Status::where('id', 4)->first()->status,
                "order_id" => preg_replace("/[^0-9]/", '', $order->khiffa_id),
                "driver_name" => $userInfo->name,
                "driver_phone" => $userInfo->phone_number,
                "access_token" => $company->khiffa_token
            ]);
            return response()->json([
                "message" => "تم تحديث حالة الطلب بنجاح",
                "order" => new OrderStatusResource($thisOrder),
            ],200);
        }else if($status == 4){
            $thisOrder = OrderStatus::create([
                'status_id' => 5, 
                'order_id' => $order->id,
            ]);
            $response = Http::post($company->company_domain.'api/order/update-status', [
                "order_status" => 5,
                "status_name" => Status::where('id', 5)->first()->status,
                "order_id" => preg_replace("/[^0-9]/", '', $order->khiffa_id),
                "driver_name" => $userInfo->name,
                "driver_phone" => $userInfo->phone_number,
                "access_token" => $company->khiffa_token
            ]);
            $wallet = Wallet::where('user_id', $user->id)->first();
            $transactions = $this->Transactions($wallet,1);
            $this->Receipt($transactions);
    
            return response()->json([
                "message" => "تم تحديث حالة الطلب بنجاح",
                "order" => new OrderStatusResource($thisOrder),
            ],200);

        }else{
            return response()->json([
                "message" => "لقد تم تسليم الطلب بالفعل!"
            ],400);
        }
    }
//
    // might be deleted
    public function sendOrder(Request $request, Order $order, OrderStatus $orderStatus)
    {
        $orderStatus = OrderStatus::where('order_id', $order->id)->withe('order'.'company')->latest()->first();
        $khiffa_id = preg_replace("/[^0-9]/", '', $order->khiffa_id);

        return response()->json([
            'order_id' => $khiffa_id,
            'status_id' => $orderStatus->status_id,
            'status' => Status::where('id', $orderStatus->status_id)->first(),
        ],200);
    }
}
