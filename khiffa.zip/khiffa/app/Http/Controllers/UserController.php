<?php

namespace App\Http\Controllers;

use App\Helper;
use App\Http\Controllers\Controller;
use App\Http\Requests\UserRequest;
use App\Http\Resources\profileInformation;
use App\Http\Resources\profileInformationResource;
use App\Http\Resources\UserResource;
use App\Jobs\Otp;
use App\Mail\OtpMail;
use App\Models\AccountInformation;
use App\Models\AccountStatus;
use App\Models\Attachment;
use App\Models\Receipt;
use App\Models\Ticket;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Storage;

class UserController extends Controller
{

    // -------------------index (get users)------------------------

    // send otp to mail
    public function OTP(String $email, User $user)
    {
        Mail::to($email)
            ->send(new OtpMail($user));
    }

    // -------------------------------register user-------------------------------
    public function store(UserRequest $request)
    {
        //dd('hi');
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'user_type_id' => 2,
            // otp
            $otp = rand(100000, 999999),
            'otp' => $otp,
            'email_verified' => false,
            $expireat = Carbon::now()->subMinute(3),
            'otp_expires_at' => $expireat,
        ]);

        if ($user->user_type_id == 2) {
            $info = AccountInformation::create([
                'national_id' => $request->national_id,
                'phone_number' => $request->phone_number,
                //'city' => strtolower($request->city),
                'user_id' => $user->id
            ]);
            $status = AccountStatus::create([
                'user_id' => $user->id,
                'status_type_id' => 1,
            ]);
        }

        // dd('hi');
        // All attachments
        if($request->hasFile('user_portrait')){ // ----------user_portrait-----------
            $user_portrait = $request->file('user_portrait');
            $extension = $user_portrait->getClientOriginalExtension();
            $attachment_name = Helper::getAttachmentName($user->id,$info->national_id,$user->name,"user-portrait",1,$extension);
            $path = $user_portrait->storeAs($user->id, $attachment_name,"public");

            $attachment = Attachment::create([
                'name' => $attachment_name,
                'path' => $path,
                'extension' => $user_portrait->getClientOriginalExtension(),
                'size' => $user_portrait->getSize(),
                'version' => 1,
                'user_id' => $user->id,
                'attachment_type_id' => 1
            ]);
        }
        if($request->hasFile('user_license')){ // -----------user_license------------
            $user_portrait = $request->file('user_license');
            $extension = $user_portrait->getClientOriginalExtension();
            $attachment_name = Helper::getAttachmentName($user->id,$info->national_id,$user->name,"user-license",1,$extension);
            $path = $user_portrait->storeAs($user->id, $attachment_name,"public");

            $attachment = Attachment::create([
                'name' => $attachment_name,
                'path' => $path,
                'extension' => $user_portrait->getClientOriginalExtension(),
                'size' => $user_portrait->getSize(),
                'version' => 1,
                'user_id' => $user->id,
                'attachment_type_id' => 2
            ]);
        }
        if($request->hasFile('user_car')){ // -----------user_car------------
            $user_portrait = $request->file('user_car');
            $extension = $user_portrait->getClientOriginalExtension();
            $attachment_name = Helper::getAttachmentName($user->id,$info->national_id,$user->name,"user-car",1,$extension);
            $path = $user_portrait->storeAs($user->id, $attachment_name,"public");

            $attachment = Attachment::create([
                'name' => $attachment_name,
                'path' => $path,
                'extension' => $user_portrait->getClientOriginalExtension(),
                'size' => $user_portrait->getSize(),
                'version' => 1,
                'user_id' => $user->id,
                'attachment_type_id' => 3
            ]);
        }

        // otp
        $user->otp_expires_at = Carbon::now()->subMinute(3);
        $user->save();
        Otp::dispatch($user)->delay(900);

        return response()->json([
            'message' => 'تم إنشاء الحساب بنجاح! الرجاء انتظار تفعيل حسابك',
        ], 200);
    }

    // ----------------------------------checking otp-------------------------------
    public function CheckOtp(Request $request,)
    {
        $user = User::where('email', $request->email)->first();
        if ($user && $user->otp == $request->otp) {
            $expireat = $user->otp_expires_at;
            //   dd($expireat);
            if (Carbon::now()->diffInMinutes($user->otp_expires_at) >= 5) {
                return response()->json(['message' => 'OTP expired'],);
            }

            $user->email_verified = true;
            $user->save();
            // dd($user->id);
            $wallet = Wallet::create([
                'amount' => 0,
                'user_id' => $user->id
            ]);
            // dd($wallet);

            return response()->json(['message' => 'User Created']);
        } else {

            return response()->json(['message' => 'Invalid OTP'], 400);
        }
    }

    // ----------------------------------login------------------------------------
    public function login(Request $request)
    {
        $loginUserData = $request->validate([
            'email' => 'required|string|email',
            'password' => 'required|min:8'
        ]);
        $user = User::where('email', $loginUserData['email'])->first();
        if (!$user || !Hash::check($loginUserData['password'], $user->password)) {
            return response()->json([
                'message' => 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            ], 401);
        }

        $token = $user->createToken($user->name . '-AuthToken')->plainTextToken;

        if ($user->user_type_id == 1) {
            return response()->json([
                'message' => 'You are on the admin page',
                'access_token' => $token,
                'user' => $user,
                'info' => AccountInformation::where('user_id', $user->id)->first(),
            ]);
        }

        // if($user->id == $delivery->id){
        //     return response()->json([
        //         '' => '',
        //         'message' => 'You are on the delivery man page',
        //         'access_token' => $token,
        //         'user' => $user,
        //         'info' => AccountInformation::where('user_id', $user->id)->first(),
        //     ]);
        // }

        return response()->json([
            'message' => 'You are on the delivery man page',
            'access_token' => $token,
            'user' => $user,
            'info' => AccountInformation::where('user_id', $user->id)->first(),
        ]);
    }

    // -----------------------------update city---------------------------------
    public function updateCity(Request $request)
    {
        $cityValid = $request->validate([
            'city' => 'required|prohibited_if:user_type_id,1|alpha|lowercase|in:makkah,jeddah'
        ]);
        $user = User::where('id', auth()->user()->id)->first();
        $info = AccountInformation::where('user_id', $user->id)->first();
///////
        // choose city at every log into the system
        if ($user->user_type_id == 2) {
            $info->update([
                'city' => $request->city,
            ]);
        }

        return response()->json([
            "message" => 'تم تحديد المدينة بنجاح!'
        ]);
    }
/////
    //-------------------------------logout------------------------------------
    public function logout()
    {
        auth()->user()->tokens()->delete();

        return response()->json([
            "message" => "logged out"
        ]);
    }

    // ----------------------------delete--------------------------------
    public function delete()
    {
        $user = User::where('id', auth()->user()->id)->first();
        $user->delete([
            'email' => auth()->user()->email
        ]);
        return response()->json([
            "message" => "Account deleted"
        ]);
    }

    // ---------------------------------resetPass-------------------------------------
    public function resetPass(Request $request)
    {
        $valid = $request->validate([
            'email' => 'required|string|email',
            'password'=>'required|confirmed|min:8',
        ]);
        $user = User::where('email', $request->email)->first();
        $email = $request->email;
        $otp = $request->otp;
       // dd($otp);
        if ($user->otp == $otp) {
            $user->update([
                'password' => Hash::make($request['password']),
            ]);
            return response()->json([
                "message" => "Data updated"
            ]);
        }
        return response()->json([
            "message" => "otp is ...."
        ]);
    }


    // --------------------------------Send Otp------------------------------
    public function sendOtp(Request $request)
    {
        $user = User::where('email', $request['email'])->first();

        if (!$user) {
            return response()->json(['message' => 'User not found'], 404);
        }
        $email = $request->email;
        $otp = rand(100000, 999999);
        $user->otp = $otp;
        $user->save();

        $this->OTP($email,  $user);
        $user->otp_expires_at = Carbon::now()->subMinute(3);
        $user->save();
    }

    //---------------------------------Profile information---------------------------------
    public function profileInformation(Request $reques)
    {
        $user = User::where('id', auth()->user()->id)->with('accountInformation')->first();

        $info = AccountInformation::where('user_id', $user->id)->first();

        $user_portrait = Attachment::where('user_id', $user->id)->where('attachment_type_id', 1)->latest()->first();
        $user_license = Attachment::where('user_id', $user->id)->where('attachment_type_id', 2)->latest()->first();
        $user_car = Attachment::where('user_id', $user->id)->where('attachment_type_id', 3)->latest()->first();

        //  dd($user);
        return response()->json([
            "user" => new ProfileInformationResource($user),
            "user_portrait" => url('/') . Storage::url($user_portrait->path),
            "user_license" => url('/') . Storage::url($user_license->path),
            "user_car" => url('/') . Storage::url($user_car->path),
        ]); 
    }

    // -----------------------------update--------------------------------
    public function update(Request $request)
    {
        // NOTE: MODIFIED THIS AND TESTED IT. IT'S WORKING AS EXPECTED!!
        $user = User::where('id', auth()->user()->id)->first();
        $info = AccountInformation::where('user_id', auth()->user()->id)->first();

        if (
            $request->email == $user->email &&
            $request->phone_number == $info->phone_number &&
            $request->bank_iban == $info->bank_iban
        ) {
            return response()->json([
                'message' => "Nothing to update!"
            ]);
        }

        if ($request->email != $user->email) {
            $registerUserData = $request->validate([
                'email' => 'nullable|string|email|unique:users',
            ]);
            $user->update([
                'email' => $registerUserData['email'],
                'email_verified' => false,
            ]);
            // otp
            $this->sendOtp($request);
        }

        if ($request->phone_number != $info->phone_number) {
            $registerUserData = $request->validate([
                'phone_number' => 'nullable|required_if:user_type_id,2|prohibited_if:user_type_id,1|digits:10|unique:account_information',
            ]);
            $info->update([
                'phone_number' => $registerUserData['phone_number'],
            ]);
        }

        if ($request->bank_iban != $info->bank_iban) {
            
            $registerUserData = $request->validate([
                'bank_iban' => 'nullable|prohibited_if:user_type_id,==,1|regex:/^[A-Z]{2}[0-9]{22}$/|starts_with:SA|unique:account_information'
            ]);
            $info->update([
                'bank_iban' => $registerUserData['bank_iban']
            ]);
        }

        $this->updateAttachments($request);
        
        return response()->json([
            "message" => "Data updated"
        ], 200);
    }

    public function updateOnReject(Request $request)
    {
        $valid = $request->validate([
            'name' => 'nullable|max:100',
            'national_id'=>'nullable|digits:10|unique:account_information',
        ]);
        $user = User::where('id', auth()->user()->id)->first();
        $info = AccountInformation::where('user_id', auth()->user()->id)->first();
        
        if($request->name != null){
            $user->update([
                'name' => $request->name,
            ]);
        }

        if($request->national_id != null){
            $info->update([
                'national_id' => $request->national_id,
            ]);
        }

        $this->updateAttachments($request);
        
        return response()->json([
            "message" => "تم تحديث معلوماتك بنجاح! يرجى انتظار تأكيد صحة البيانات المرسلة",
        ],200);
    }

    public function updateAttachments(Request $request)
    {
        $valid = $request->validate([
            'user_portrait'=>'nullable|mimes:png,jpg,jpeg,pdf|max:5000',
            'user_license'=>'nullable|mimes:png,jpg,jpeg,pdf|max:5000',
            'user_car'=>'nullable|mimes:png,jpg,jpeg,pdf|max:5000',
        ]);
        $user = User::where('id', auth()->user()->id)->first();
        $info = AccountInformation::where('user_id', auth()->user()->id)->first();

        // All attachments
        if($request->hasFile('user_portrait')){ // ----------user_portrait-----------
            $user_portrait = $request->file('user_portrait');
            $extension = $user_portrait->getClientOriginalExtension();
            $lastAttachment = Attachment::where('user_id', $user->id)->where('attachment_type_id',1)->latest()->first();
            if($lastAttachment != null){ // if there is a last attachment 
                $version = $lastAttachment->version + 1;
            }else{
                $version = 1;
            }
            $attachment_name = Helper::getAttachmentName($user->id,$info->national_id,$user->name,"user-portrait",$version,$extension);
            $path = $user_portrait->storeAs($user->id, 'storage/'.$attachment_name,"public");

            $attachment = Attachment::create([
                'name' => $attachment_name,
                'path' => $path,
                'extension' => $user_portrait->getClientOriginalExtension(),
                'size' => $user_portrait->getSize(),
                'version' => $version,
                'user_id' => $user->id,
                'attachment_type_id' => 1
            ]);
        }
        if($request->hasFile('user_license')){ // -----------user_license------------
            $user_portrait = $request->file('user_license');
            $extension = $user_portrait->getClientOriginalExtension();
            $lastAttachment = Attachment::where('user_id', $user->id)->where('attachment_type_id',2)->latest()->first();
            if($lastAttachment != null){ // if there is a last attachment 
                $version = $lastAttachment->version + 1;
            }else{
                $version = 1;
            }
            $attachment_name = Helper::getAttachmentName($user->id,$info->national_id,$user->name,"user-license",$version,$extension);
            $path = $user_portrait->storeAs($user->id, $attachment_name,"public");
            
            $attachment = Attachment::create([
                'name' => $attachment_name,
                'path' => $path,
                'extension' => $user_portrait->getClientOriginalExtension(),
                'size' => $user_portrait->getSize(),
                'version' => $version,
                'user_id' => $user->id,
                'attachment_type_id' => 2
            ]);
        }
        if($request->hasFile('user_car')){ // -----------user_car------------
            $user_portrait = $request->file('user_car');
            $extension = $user_portrait->getClientOriginalExtension();
            $lastAttachment = Attachment::where('user_id', $user->id)->where('attachment_type_id',3)->latest()->first();
            if($lastAttachment != null){ // if there is a last attachment 
                $version = $lastAttachment->version + 1;
            }else{
                $version = 1;
            }
            $attachment_name = Helper::getAttachmentName($user->id,$info->national_id,$user->name,"user-car",$version,$extension);
            $path = $user_portrait->storeAs($user->id, $attachment_name,"public");
            
            $attachment = Attachment::create([
                'name' => $attachment_name,
                'path' => $path,
                'extension' => $user_portrait->getClientOriginalExtension(),
                'size' => $user_portrait->getSize(),
                'version' => $version,
                'user_id' => $user->id,
                'attachment_type_id' => 3
            ]);
        }

        return response()->json([
            "message" => "تم تحديث معلوماتك بنجاح! يرجى انتظار تأكيد صحة البيانات المرسلة",
        ],200);
    }

    
    /*   public function paginatingTrnReq(Request $request)
    {
        
        $transaction = transaction::where('id',auth()->user()->id)->latest()->paginate(3);

        return response()->json([$transaction]);
        } */


    // paginating Latest Transaction 
    public function paginatingLsTrsnDel(Request $request)
    {
       // dd(auth()->user()->id);
       $wallet = wallet::where('user_id', auth()->user()->id)->first();
        
        $transaction = transaction::where('Wallet_id', $wallet->id)->latest()->paginate(10);
 
        return response()->json([$transaction]);
    }

    public function walletDel(Request $request)
    {
        $wallet = wallet::where('user_id', auth()->user()->id)->get();
        
        //dd($wallet);
        return response()->json([
         'wallet'  => $wallet,
          'tranactin' => $this->paginatingLsTrsnDel($request),
            //  $this->   paginatingTrnReq($request),
        ]);
    }

    public function showTicketDel(Request $request)
    {
        //dd('جميل جدا');
        $ticket = Ticket::where('user_id', auth()->user()->id)->get();
        // dd($ticket);
        // dd($ticket);
        return response()->json([
            $ticket
        ]);
    }

}
