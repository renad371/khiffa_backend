<?php

namespace App\Http\Controllers;

use App\Models\attachment_statuses;
use Illuminate\Http\Request;

class AttachmentStatusesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\attachment_statuses  $attachment_statuses
     * @return \Illuminate\Http\Response
     */
    public function show(attachment_statuses $attachment_statuses)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\attachment_statuses  $attachment_statuses
     * @return \Illuminate\Http\Response
     */
    public function edit(attachment_statuses $attachment_statuses)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\attachment_statuses  $attachment_statuses
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, attachment_statuses $attachment_statuses)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\attachment_statuses  $attachment_statuses
     * @return \Illuminate\Http\Response
     */
    public function destroy(attachment_statuses $attachment_statuses)
    {
        //
    }
}
