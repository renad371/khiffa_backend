<?php

namespace App\Http\Controllers;

use App\Http\Requests\ServiceProviderRequest;
use App\Models\Address;
use App\Models\Attachment;
use App\Models\Company;
use App\Models\CompanyService;
use App\Models\ServiceProvider;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Helper;

class ServiceProviderController extends Controller
{
    // ------------------------------get service providers--------------------------
    public function index()
    {
        $serviceProvider= ServiceProvider::all();
        return $serviceProvider;
    }

    // ----------------------store service provider (coming from other companies)-------------------------
    public function store(ServiceProviderRequest $request)
    {
        // find the company that sent the request using the company_token
        $company = Company::where('company_token', $request->company_token)->first(); // the company that sent the request

        if($request->company_token == null || $company == null){
            return response()->json([
                'You are not authorized to do this action'
            ],401);
        }

        $address = Address::where('city', $request->city)->where('district', $request->district)->first();
        if($address == null){
            // address of service provider
            $address = Address::create([
                'city' => $request->city,
                'district' => $request->district,
                'address_type_id' => 1,
            ]);
        }

        $khiffa_id = Helper::getKhiffaId($company->company_name,$request->service_provider_id);

        $serviceProvider = ServiceProvider::where('khiffa_id', $khiffa_id)->first();

        if($serviceProvider != null){
            return response()->json([
                'error'=> 'The service provider khiffa id has already been taken.',
            ],422);
        }

        // service provider info
        $serviceProvider = ServiceProvider::create([
            'khiffa_id' => $khiffa_id,
            'name' => $request->name,
            'location_x' => $request->location_x,
            'location_y' => $request->location_y,
            'polygon' => $request->polygon,
            'path' => $request->path,
            'address_id' => $address->id,
        ]);

        // connect the company with the service provider by creating a company service instance
        $companyService = CompanyService::create([
            'company_id' => $company->id,
            'service_provider_id' => $serviceProvider->id,
        ]);
        
        return response()->json([
            "message" => "Service Provider Added"
        ],200);
    }
}
