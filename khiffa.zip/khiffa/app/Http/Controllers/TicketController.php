<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use App\Models\TicketStatus;
use App\Models\User;
use Illuminate\Http\Request;

class TicketController extends Controller
{
    public function countAllTicket()
    {
            $Ticket = Ticket::all()->count();
        return $Ticket;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = User::where('id', auth()->user()->id)->first();

        $Ticket = Ticket::create([
            'user_id' => $user->id,
            'title' => $request->title,
            'description' => $request->description,

        ]);
        $ticketStatus = TicketStatus::create([

            'ticket_id' => $Ticket->id,
            'status_type_id' => 5,

        ]);
    }
    public function showallTicket(Request $request)
    {
        $user = User::where('id', auth()->user()->id)->first();

        if ($user->user_type_id == 1) {

            //  $ticketStatus = TicketStatus::where('status_type_id','=',$request)->get();

            $user = User::where('id', auth()->user()->id)->first();

            if ($user->user_type_id == 1) {

                //  $ticketStatus = TicketStatus::where('status_type_id','=',$request)->get();

                $TicketStatus = TicketStatus::with('Ticket')->get();

                return response()->json([
                    $TicketStatus,

                ]);
            }
        }
    }

    public function ticketStatuses (Request $request)
{
    $user = User::where('id', auth()->user()->id)->first();

    
    if ($user->user_type_id == 1) {
        //$closedTickets = TicketStatus::where('status_type_id', 4)->count();
        $ticketStatuses = TicketStatus::with('ticket')->get();

        $statusCounts = [
            'Pending' => 0,
            'Open' => 0,
            'In_Progress' => 0,
            'Closed' => 0
        ];
//dd($ticketStatuses);
       
        foreach ($ticketStatuses as $ticketStatus) {
         //   dd($ticketStatuses ,$ticketStatus);
         
                //dd($ticketStatus->status_type_id);
                switch ($ticketStatus->status_type_id) {
                   
                    case '5':
                        $statusCounts['Pending']++;
                        break;
                    case '6':
                        $statusCounts['Open']++;
                        break;
                    case '7':
                        $statusCounts['In_Progress']++;
                        break;
                    case '8':
                        $statusCounts['Closed']++;
                        break;
                }
                }
            
            }

//
        return response()->json([
            'status_counts' => $statusCounts,
            
        ]);
    }

    //return response()->json(['message' => 'Unauthorized'], 403);



    public function showTicket(Request $request)
   {
        $user = User::where('id', auth()->user()->id)->first();

        if ($user->user_type_id == 1) {

       //     $ticketStatus = TicketStatus::where('status_type_id', '=', $request->status)->with('Ticket')->get();
    
            $Ticket = Ticket::where('id',$request->id)->first();
         

            return response()->json([
                $Ticket,

            ]);
        }
        return response()->json([
          'غير مصرح لك القيام بهذا الإجراء!',

        ]);
    }

    

    public function changeTicketStatus(Request $request)
    {
        $user = User::where('id', auth()->user()->id)->first();


        if ($user->user_type_id == 1) {

            $Ticket = Ticket::where('id', $request['id'])->first();

            $ticketStatus = TicketStatus::create([

                'ticket_id' => $Ticket->id,
                'status_type_id' => $request->status,
                "description" =>$request->description,


      
            ]);
            return response()->json([
                'message' => ' Ticket updated'
                
            ]);
        }
    }

    //  public function delete()
    //  {
    //    $user = User::where('id', auth()->user()->id)->first();










    //  $user->delete([
    //    'email' => auth()->user()->email
    //  ]);
    // return response()->json([
    //     "message" => "Account deleted"
    //  ]);


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    //  public function store(Request $request)
    //{
    //
    // }

    /**
     * Display the specified resource.
   *
     * @param  \App\Models\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        //
    }

    /**
     * Update the specified resource in storage.

     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Request $receipt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */

     public function destroy(Request $receipt)
    {
        //
    }
}
















