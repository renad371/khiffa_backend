<?php

namespace App\Http\Controllers;

use App\Helper;
use App\Http\Requests\AccountRejectionRequest;
use App\Http\Requests\UserRequest;
use App\Http\Resources\UserResource;
use App\Mail\MessageMail;
use App\Models\AccountInformation;
use App\Models\AccountStatus;
use App\Models\Ticket;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class AdminController extends Controller
{

    // -------------------index (get users)------------------------

    public function index()
    {
        //$user= User::all();
	    //return $user;
	   
        $users= User::where('user_type_id', 2)->paginate(6);
        return UserResource::collection($users);

       /*  $users = User::with('userType')->get();
        return $users; */
    }

    public function registerAdmin(UserRequest $request)
    {
        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'user_type_id' => 1,
            // otp
            $otp = rand(100000, 999999),
            'otp' => $otp,
            'email_verified' => false,
            $expireat = Carbon::now()->subMinute(3),
            'otp_expires_at' => $expireat,
        ]);
    }

    // sent message in email
    public function message(String $email, User $user)
    {
        Mail::to($email)
            ->send(new MessageMail($user));
    }
    public function checkAdmin()
    {
        return 'You are on the admin page ';
    }


    // ------------------------------------------show Management Deliveries ----------------------------------
    public function Deliveries(Request $request)
    {
        

        $users = User::with('accountInformation','lastStatus')
        
        //->whereHas('status_type_id', [2,3])
        ->paginate($request->perPage);
       
        return $users;
    }
    
    public function accountRequests(Request $request)
    {
        $result = [];
        $skip = 0;
        $perPage = 5;
        $currentPage = 1;

        // if user sets specific perPage
        if ($request->perPage) {
            $perPage = (int)$request->perPage;
        }

        // if user sets specific page
        if ($request->page) {
            $currentPage = (int)$request->page;
            $skip = (int) $perPage * ($currentPage - 1);
        }

        // $user = User::where('email_verified', false)->skip($skip)->limit($perPage)->with('accountInformation')->get();
        $user = User::with('lastStatus')->whereHas('lastStatus', function($q){
            $q->whereIn('status_type_id', [4,1]);
        })-> get();
      //  $info = AccountStatus::whereIn('status_type_id', [4,1])->skip($skip)->limit($perPage)->with('user.accountInformation')->get();

        $result[] = [
            // 'user'=>  UserResource::collection($user),
            'user' => $user,
          
        ];
        return response()->json([
            'message' => '',
            'current_page' => $currentPage,
            'per_page' => $perPage,
            'data' => $result,
        ], 200);
    }


    public function showManagementDeliveries(Request $request)
    {
        $Deliveries = $this->Deliveries();
        $accountRequests = $this->accountRequests($request);
        return response()->json([

            'Deliveries' => $Deliveries,
            'accountRequests' => $accountRequests,

        ], 200);
    }


    public function changeAccountStatus(Request $request)
    {
        $user = User::where('id', auth()->user()->id)->first();

        if ($user->user_type_id == 1) {


            $delivery = User::where('id', $request['id'])->first();
            $info = AccountInformation::where('user_id', $delivery->id)->first();
         //   dd($info);
            //   dd($info);

            $accountStatus = AccountStatus::create([

                'user_id' => $delivery->id,
                'status_type_id' => $request->status,
                'description' => $request->description,

            ]);

            $this->message($delivery->email, $delivery);
            return response()->json([
                'message' => 'Account status updated '
            ]);
        }
    }

    public function showInfoAccountReq(Request $request)
    {

        $AccountStatus = AccountStatus::where('user_id', $request->user_id)->first();
        $user = user::where('id', $AccountStatus->user_id)->with('accountInformation')->first();
        return response()->json([$user]);
    }

    //------------------------------------paginating Ticket---------------------------------
    public function paginatingTicket(Request $request)
    {
        $statusType = $request->status ? $request->status : 'all';
      //  $statusType = ? :$request->status;
        $q = Ticket::latest()->with('ticketStatuses.StatusType');
     
     if ($statusType != 'all') {
    
        $q->whereHas('ticketStatuses', function ($q) use ($statusType) {
            $q->where('status_type_id', $statusType);
        });
    }

    
    $tickets = $q->paginate(5);

        return response()->json([$tickets]);
    }

    //show  Ticket
    public function showTicket(Request $request)
    {
        $ticket = Ticket::where('id', $request->id)->with('lastStatus.')->first();
        $user=user::where('id',$ticket->user_id)->first();
       // dd($ticket);
       // dd($ticket);
        return response()->json([
            "ticket" =>$ticket,
             "name"=>$user->name,
        
        ]);
    }

    // ----------------------------------paginating Transaction Request--------------------------------
    public function paginatingTrnReq(Request $request)
    {

        $transaction = transaction::latest()->paginate(3);

        return response()->json([$transaction]);
    }


    // ------------------------------------paginating Latest Transaction ------------------------------------
    public function paginatingLsTrsn(Request $request)
    {

        $transaction = transaction::latest()->paginate(10);

        return response()->json([$transaction]);
    }
    
    public function wallet(Request $request){
        $wallet = wallet::where('user_id', auth()->user()->id)->first();
        return response()->json([
                    $wallet->amount ,
            $this->paginatingLsTrsn( $request),
            $this->paginatingTrnReq($request),
        ]);
    }
    

    // ------------------------------------Account Rejection--------------------------------------
    public function rejectionDescription(AccountRejectionRequest $request)
    {
        $admin = User::where('id', auth()->user()->id)->first(); // get authorized user (must be admin here so needs validation)
        // dd();
        $delivery = User::where('id', $request->id)->first(); // the user_id from request must be a delivery
        //dd($delivery);
        //dd($admin);
        $info = AccountInformation::where("user_id", $delivery->id)->first();
        //dd($info);
        $accountStatus = AccountStatus::where('user_id', $delivery->id)->latest()->first();
        
        // dd($accountStatus);
        $accountStatus->update([
            'description' => $request->description,
        ]);

        // dd("hi");

        if($delivery == null && $delivery->user_type_id == 1){ // if there is no such user or the user is admin
            return response()->json([
                "message:" => "حدث خطأ في معالجة البيانات التي أدخلتها"
            ],422);
        }

        $reject = [
            'national' => $request->national_id,
            'name' => $request->name,
            'portrait' => $request->user_portrait,
            'license' => $request->user_license,
            'car' => $request->user_car,
        ];

        //dd($reject);
        if($admin->user_type_id == 1){ // if user is admin do some logic
            $info->update([
                'must_edit' => $reject
            ]);
            return response()->json([
                "message:" => "تم إرسال البيانات للمستخدم بنجاح!"
            ],200);
        }
        return response()->json([
            "message:" => "غير مصرح لك القيام بهذا الإجراء!"
        ],401);
    }
}
