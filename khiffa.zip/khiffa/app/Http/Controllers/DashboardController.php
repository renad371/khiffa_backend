<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\CompanyService;
use App\Models\Order;
use App\Models\OrderStatus;
use App\Models\User;
use Carbon\Carbon;
use Carbon\CarbonInterval;
use DatePeriod;
use Illuminate\Http\Request;

class DashboardController extends Controller
{

    public function index(Request $request)
    {
        $city = $request->city ?? null;

        $startDate = $request->start_date ? Carbon::parse($request->start_date)->format('Y-m-d H:i:s') : Carbon::now()->subYear()->format('Y-m-d H:i:s');
        $endDate = $request->end_date ? Carbon::parse($request->end_date)->format('Y-m-d H:i:s') : Carbon::now()->format('Y-m-d H:i:s');

        $classification = $request->classification ?? null;

        $deliveryCount = $this->countDelivery();

        $serviceProviders = $this->countServiceProvidersByCompany();
        $orderCountsByCompany = $this->countOrderByCompany($city, $startDate, $endDate);

        $allOrderCounts = $this->countAllOrder($city, $startDate, $endDate);
        $Timeline = $this->Timeline($city, $startDate, $endDate, $classification);

        return response()->json([
            'delivery_Count' => $deliveryCount,
            'service_Providers' => $serviceProviders,
            'order_Counts_By_Company' => $orderCountsByCompany,
            'all_Order_Counts' => $allOrderCounts,
            "time_line" => $Timeline,
        ]);
    }


    public function minDate()
    {
        $order = Order::where('id', 1)->first();

        return $order;
    }

    public function countDelivery()
    {
        $user = User::where('user_type_id', 2)->count();

        return $user;
    }


    public function countServiceProvidersByCompany()
    {

        $result = [];
        $q = Company::withCount('companyServices');

        $companies = $q->get();

        foreach ($companies as $company) {
            $result[] = [
                'company_Name' => $company->company_name,
                'Service_Providers' => $company->company_services_count
            ];
        }
        return $result;
    }




    public function countOrderByCompany($city = null, $startDate = null, $endDate = null)
    {
        $result = [];
        $companies = Company::with(['orders.orderStatuses', 'orders.address', 'orders'])

            ->whereHas('orders', function ($q) use ($city, $endDate, $startDate) {

                $q->whereBetween('created_at', [$startDate, $endDate])
                ->whereHas('address', function ($q) use ($city) {
                    if ($city) {
                        $q->where('city', $city);
                    }
                });
            })->get();
           // dd($ecompanies);  
        foreach ($companies as $company) {

            $orders = $company->orders()->withCount('orderStatuses')->get();

            $statusCounts = [
                'pending' => $orders->pluck('lastStatus')->where('status_id', null)->count(),
                'in_progress' => $orders->pluck('lastStatus')->whereIn('status_id', [1, 2, 3, 4])->count(),
                'completed' => $orders->pluck('lastStatus')->where('status_id', 5)->count(),
                'cancelled' => $orders->pluck('lastStatus')->where('status_id', 6)->count(),
            ];

            $result[] = [
                'company_Name' => $company->company_name,
                'status_counts' => $statusCounts,
            ];
        }
        return $result;
    }



    public function countAllOrder($city = null, $startDate = null, $endDate = null)
    {
        $orders = Order::with('lastStatus')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->whereHas('address', function ($q) use ($city) {
                if ($city) {
                    $q->where('city', $city);
                }
            })
            ->get();

        // return $orders->pluck('lastStatus');
        $statusCounts = [
            'pending' => $orders->pluck('lastStatus')->where('status_id', null)->count(),
            'in_progress' => $orders->pluck('lastStatus')->whereIn('status_id', [1, 2, 3, 4])->count(),
            'completed' => $orders->pluck('lastStatus')->where('status_id', 5)->count(),
            'cancelled' => $orders->pluck('lastStatus')->where('status_id', 6)->count(),
        ];

        return $statusCounts;
    }




    public function Timeline($city = null, $startDate = null, $endDate = null, $classification = null)
    {

        $startHour = Carbon::parse($startDate);
        $endHour = Carbon::parse($endDate);
        $interval = ($classification == 1) ?   CarbonInterval::year() : CarbonInterval::month();
        $periods = new DatePeriod($startHour, $interval, $endHour);
        $labels = [];
        foreach ($periods as $period) {
            array_push($labels, Carbon::parse($period)->format('M'));
        }

        $labels = [];
        foreach ($periods as $period) {
            $format = ($classification == 1) ?  'Y' : 'M';
            array_push($labels, Carbon::parse($period)->format($format));
        }


        $companies = Company::with(['orders.address', 'orders'])

            ->whereHas('orders', function ($q) use ($city, $endDate, $startDate) {

                $q->whereBetween('created_at', [$startDate, $endDate]);

                $q->whereHas('address', function ($q) use ($city) {
                    if ($city) {
                        $q->where('city', $city);
                    }
                });
            })->get();


        $data = [];
        foreach ($companies as $company) {
            $values = [];
            foreach ($periods as $period) {
                $startPeriod = Carbon::parse($period);
                $endPeriod = ($classification == 1) ?   $startPeriod->copy()->addYear() : $startPeriod->copy()->addMonth();
                array_push(
                    $values,
                    $company->orders
                        ->whereBetween('created_at', [$startPeriod, $endPeriod])
                        ->count()
                );
            }
            array_push($data, [
                'company_name' => $company->company_name,
                'values' => $values,
            ]);
        }
        $result = [
            'labels' => $labels,
            'data' => $data,
        ];
        return $result;
    }
}
