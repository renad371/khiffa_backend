<?php

namespace App\Http\Controllers;

use App\Http\Requests\CompanyRequest;
use App\Models\Company;
use Illuminate\Http\Request;

class CompanyController extends Controller
{
    // --------------------------get companies----------------------------------
    public function index()
    {
        $order= Company::all();
        return $order;
    }

    // ----------------------------store company-------------------------------
    public function store(CompanyRequest $request)
    {
        $company = Company::create([
            'company_name' => $request->company_name,
            'arabic_name' => $request->arabic_name,
            'company_domain' => $request->company_domain,
            'khiffa_token' => $request->khiffa_token,
        ]);
        $token = $company->createToken($company->company_name . '-AuthToken')->plainTextToken;
        $company->update([
            'company_token' => $token,
        ]);
        return response()->json([
            "company" => $request->company_name,
            "access_token" => $token
        ]);
    }
}
