<?php

namespace App\Http\Controllers;

use App\Models\Receipt;
use App\Models\Transaction;
use App\Models\User;
use App\Models\Wallet;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Receipt($transaction){
        // dd($transaction->id);
         $receipts = Receipt::create([
             'transaction_id' => $transaction->id,
         ]);
     }
 
     public function Transactions($wallet,$transaction_type_id){
         $transactions = Transaction::create([
         'price' => $wallet->amount,
         'processed' => 0,
         'wallet_id' => $wallet->id,
         'transaction_type_id' => $transaction_type_id,
         ]);
         return  $transactions;
     }
 
     // طلب التحويل عند وصول المحفظه ل200
     public function  requestTransactions()
     {
 
         $user = User::where('id', auth()->user()->id)->first();
 
         $wallet = Wallet::where('user_id', $user['id'])->first();
 
         if ($wallet->amount >= 200) {
             $transactions = $this->Transactions($wallet,3);
           //  $transactions = Transaction::create([
 
              //   'price' => $wallet->amount,
                 //'processed' => 0,
                // 'wallet_id' => $wallet->id,
                // 'transaction_type_id' => 3,
           //  ]);
             return response()->json([
                 'message' => 'Success'
             ]);
         }
     }
         // عرض  طلبات التحويل  

         public function showTransactions()
         {
             $user = User::where('id', auth()->user()->id)->first();
     
             if ($user->user_type_id == 1) {

                 $transactions = transaction::where('processed', false)->get();
                 return response()->json([
                     $transactions,
     
                 ]);
             }else{
                return response()->json([
                    "message" => "غير مصرح لك القيام بهذا الإجراء!"
                ], 401);
             }
         }
 
         // قبول طلب التحويل للمندوب 
     public function  sendTransactions(Request $request)
     {
 
         $user = User::where('id', auth()->user()->id)->first();
 
         if ($user->user_type_id == 1) {
 
             $transactions = Transaction::where('id', $request['id'])->first();
             $transactions->update([
                 'processed' => 1
             ]);
             $this-> Receipt($transactions);
   //dd($transactions);
             if ($transactions->price >= 200) {
 
 
                 $walletdil = Wallet::where('id', $transactions['wallet_id'])->first();
 
             
                 $walletadm = Wallet::where('user_id', $user->id)->first();
                 $transactionadm =$this->Transactions($walletadm,2);
 
                 $walletadm->decrement('amount', $transactionadm->price);
 
 
 
                 $walletdil->update([
                     'amount' => 0
                 ]);
                 $this-> Receipt($transactionadm);
                
                 return response()->json([
                     'message' => 'Success'
                 ]);
             }
             return response()->json([
                 'message' => 'error'
             ]);
         }
     }
 
}
