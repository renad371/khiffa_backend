<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class OrderRequest extends FormRequest
{
    //protected $stopOnFirstFailure = true;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            // NOTE:: should have written it but was so tired so i am gonna do it on monday
            'beneficiary_name' => 'required|string',
            'phone_number'=> 'required|digits:10',
            'beneficiary_city'=> 'required|alpha|lowercase|in:makkah,jeddah',
            'beneficiary_district'=> 'required|alpha|lowercase',
            'delivery_cost' => 'required|numeric', // float
            'distance' => 'required|numeric',
            'service_provider_id' => 'required|integer',
            'order_id' => 'required|integer',
        ];
    }
}
