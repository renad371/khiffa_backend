<?php

namespace App\Http\Requests;

use Illuminate\Contracts\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{

    protected $stopOnFirstFailure = true;

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name'=> 'bail|required|max:100',
            'email'=>'bail|required|string|email|unique:users',
            'password'=>'bail|required|confirmed|min:8',
            'user_type_id'=>'bail|between:1,2|exists:user_types,id',
            // otp
            //'otp'=>'required|digits:6',
            //'email_verified' =>'boolean', 
            'otp_expires_at'=>'optional',
            //accountInformation
            'national_id'=> 'bail|nullable|required_if:user_type_id,2|prohibited_if:user_type_id,1|digits:10|unique:account_information',
            'phone_number'=> 'bail|nullable|required_if:user_type_id,2|prohibited_if:user_type_id,1|digits:10|starts_with:05|unique:account_information',
            'city'=> ['bail','nullable', 'prohibited_if:user_type_id,1','alpha', 'lowercase',
            'in:makkah,jeddah'],
            'bank_iban'=> 'bail|nullable|prohibited_if:user_type_id,==,1|starts_with:SA|digits:22|unique:account_information',
            //attachments
            'user_portrait'=>'nullable|required_if:user_type_id,2|mimes:png,jpg,jpeg,pdf|max:5000',
            'user_license'=>'nullable|required_if:user_type_id,2|mimes:png,jpg,jpeg,pdf|max:5000',
            'user_car'=>'nullable|required_if:user_type_id,2|mimes:png,jpg,jpeg,pdf|max:5000',
            // 'attachment_name'=>'nullable|',
            // 'attachment_path'=>'nullable|mimes:png,jpg,pdf',
            // 'extension'=>'',
            // 'size'=>''
        ];
    }
}
