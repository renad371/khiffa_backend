<?php

namespace App\Http\Resources;

use App\Models\AccountInformation;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class AccountInformationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
      //  dd($request);
      $user = User::where('email', $request->email)->first();
      $info= AccountInformation::where('user_id',$user->id)->first();

        return [
            'national_id' => $info->national_id,
            'name' => $info->name,
            'phone_number'=> $info->phone_number,
        ];
    }
}
