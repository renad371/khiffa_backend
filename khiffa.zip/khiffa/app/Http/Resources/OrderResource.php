<?php

namespace App\Http\Resources;

use App\Models\Address;
use App\Models\Beneficiary;
use App\Models\Company;
use App\Models\Receipt;
use App\Models\ServiceProvider;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            "id"=> $this->id,
            "delivery_cost"=> $this->delivery_cost,
            "distance"=> $this->distance,
            "company"=> [
                "id" => $this->company_id,
                "company_name" => Company::where('id', $this->company_id)->first()->company_name
            ],
            "service_provider"=> ServiceProvider::where('id', $this->service_provider_id)->first(),
            "receipt"=> Receipt::where('id', $this->receipt_id)->first(),
            "user"=> User::where('id', $this->user_id)->first(),
            "beneficiary"=> Beneficiary::where('id', $this->beneficiary_id)->first(),
            "address"=> Address::where('id', $this->address_id)->first(),
        ];
    }
}
