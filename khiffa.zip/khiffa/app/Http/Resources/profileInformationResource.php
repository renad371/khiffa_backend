<?php

namespace App\Http\Resources;

use App\Models\AccountInformation;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class profileInformationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
      //  $user = User::where('email', $request->email)->first();

        return [
            'name' => $this->accountInformation->name,
            'email' => $this->email,
            'national_id' => $this->accountInformation->national_id,
            'phone_number' => $this->accountInformation->phone_number,
            'bank_iban' => $this->accountInformation->bank_iban,
        ];
    }
}
