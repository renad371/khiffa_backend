<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Ticket extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'title',
        'description',
        
    ];
    

    // user: MANY TO ONE (naming convention: Singular, camelCase)
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    
    }

    // TicketStatus: ONE TO MANY (naming convention: Plural, camelCase)
    public function ticketStatuses(): HasMany
    {
        return $this->hasMany(TicketStatus::class);
    }
    public function lastStatus(): HasOne
    {
        return $this->hasOne(TicketStatus::class)->latest();
    }
}
