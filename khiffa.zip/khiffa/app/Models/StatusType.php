<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class StatusType extends Model
{
    use HasFactory;



    
    // accountStatus: ONE TO MANY (naming convention: Plural, camelCase)
    public function accountStatuses(): HasMany
    {
        return $this->hasMany(AccountStatus::class);
    }

    // TicketStatus: ONE TO MANY (naming convention: Plural, camelCase)
    public function ticketStatuses(): HasMany
    {
        return $this->hasMany(TicketStatus::class);
    }
    public function attachment_types(): HasMany
    {
        return $this->hasMany(attachment_statuses::class);
    }
}
