<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ServiceProvider extends Model
{
    use HasFactory;

    protected $fillable = [
        'khiffa_id',
        'name',
        'location_x',
        'location_y',
        'polygon',
        'path',
        'address_id',
        'attachment_id',
        'city',
        'district',
        'address_type_id',
        // 'path',
        // 'extension',
        // 'size',
        // 'path',
        // 'attachment_date'
    ];

    // Address: ONE TO ONE (naming convention: Singular, camelCase)
    public function address(): HasOne
    {
        return $this->hasOne(Address::class);
    }

    // CompanyService: ONE TO MANY (naming convention: Plural, camelCase)
    public function companyServices(): HasMany
    {
        return $this->hasMany(CompanyService::class);
    }

    // Order: ONE TO MANY (naming convention: Plural, camelCase)
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    // Attachment: ONE TO ONE (naming convention: Singular, camelCase)
    // public function attachment(): HasOne
    // {
    //     return $this->hasOne(Attachment::class);
    // }
}
