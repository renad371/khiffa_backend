<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Address extends Model
{
    use HasFactory;

    protected $fillable = [
        'city',
        'district',
        'address_type_id',
    ];

    // Order: ONE TO ONE (naming convention: Singular, camelCase)
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    // Address: ONE TO ONE (naming convention: Singular, camelCase)
    public function serviceProvider(): HasOne
    {
        return $this->hasOne(ServiceProvider::class);
    }

    // AddressType: MANY TO ONE (naming convention: Singular, camelCase)
    public function addressType(): BelongsTo
    {
        return $this->belongsTo(AddressType::class);
    }
}
