<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Receipt extends Model
{
    use HasFactory;
    protected $fillable = [
       
        'transaction_id',
       
        
    ];
    // Order: ONE TO ONE (naming convention: Singular, camelCase)
    public function order(): HasOne
    {
        return $this->hasOne(Order::class);
    }

    // transaction: ONE TO ONE (naming convention: Singular, camelCase)
    public function transaction(): HasOne
    {
        return $this->hasOne(Transaction::class);
    }
}
