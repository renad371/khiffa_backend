<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CompanyService extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'service_provider_id'
    ];

    // Company: MANY TO ONE (naming convention: Singular, camelCase)
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    // ServiceProvider: MANY TO ONE (naming convention: Singular, camelCase)
    public function serviceProvider(): BelongsTo
    {
        return $this->belongsTo(ServiceProvider::class);
    }
}
