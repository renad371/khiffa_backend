<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class TicketStatus extends Model
{
    use HasFactory;
    protected $fillable = [
        'ticket_id',
        'status_type_id',
       
        
    ];
    // Ticket: MANY TO ONE (naming convention: Singular, camelCase)
    public function ticket(): BelongsTo
    {
        return $this->belongsTo(Ticket::class);
    
    }

    // statusType: MANY TO ONE (naming convention: Singular, camelCase)
    public function statusType(): BelongsTo
    {
        return $this->belongsTo(StatusType::class);
    
    }

   
}
