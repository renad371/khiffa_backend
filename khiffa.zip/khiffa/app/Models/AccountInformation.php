<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class AccountInformation extends Model
{
    use HasFactory;

    protected $casts  = [
        'must_edit' => 'array'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'national_id',
        'phone_number',
        'city',
        'bank_iban',
        'must_edit',
        'user_id', 
        'Update_request',
    ];

    // User: ONE TO ONE (naming convention: Singular, camelCase)
    public function user(): HasOne
    {
        return $this->hasOne(User::class);
    }
}
