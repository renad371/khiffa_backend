<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Laravel\Sanctum\HasApiTokens;

class Company extends Model
{
    use HasApiTokens, HasFactory;

    protected $fillable = [
        'company_name',
        'company_token',
        'arabic_name',
        'company_domain',
        'khiffa_token'
    ];

    // Order: ONE TO MANY (naming convention: Plural, camelCase)
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    // CompanyService: ONE TO MANY (naming convention: Plural, camelCase)
    public function companyServices(): HasMany
    {
        return $this->hasMany(CompanyService::class);
    }
}
