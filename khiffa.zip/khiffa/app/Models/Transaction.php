<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Transaction extends Model
{
    use HasFactory;

    protected $fillable = [
    'price',
    'processed',
    'wallet_id',
    'transaction_type_id',
        
    ];
    
    
    
    // Wallet: MANY TO ONE (naming convention: Singular, camelCase)
    public function wallet(): BelongsTo
    {
        return $this->belongsTo(Wallet::class);
    
    }

    // TransactionType: MANY TO ONE (naming convention: Singular, camelCase)
    public function transactionType(): BelongsTo
    {
        return $this->belongsTo(TransactionType::class);
    
    }

    // Receipt: ONE TO ONE (naming convention: Singular, camelCase)
    public function receipt(): HasOne
    {
        return $this->hasOne(Receipt::class);
    }
}
