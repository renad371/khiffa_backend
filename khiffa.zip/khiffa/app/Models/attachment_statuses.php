<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class attachment_statuses extends Model
{
    use HasFactory;
    protected $fillable = [
        'attachment_id',
        'status_type_id',
    ] ; 

    public function statusType(): BelongsTo
    {
        return $this->belongsTo(StatusType::class);
    
    }
    public function attachment(): BelongsTo
    {
        return $this->belongsTo(attachment::class);
    
    }
}
