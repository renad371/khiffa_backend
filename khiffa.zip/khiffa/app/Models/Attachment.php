<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Attachment extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'path',
        'extension',
        'size',
        'version',
        'user_id',
        'attachment_type_id'
        //'attachment_date', --no need--
    ];

    // Users: MANY TO ONE (naming convention: Singular, camelCase)
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // ServiceProvider: ONE TO ONE (naming convention: Singular, camelCase)
    // public function serviceProvider(): HasOne
    // {
    //     return $this->hasOne(ServiceProvider::class);
    // }

    public function attachmentType(): BelongsTo
    {
        return $this->BelongsTo(attachment_types::class);
    }

    public function attachmentStatuses(): HasMany
    {
        return $this->HasMany(attachment_statuses::class);
    }
}
