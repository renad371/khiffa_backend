<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\Wallet;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [  
        'name',
        'email',
        'password',
        'password_confirmation',
        'user_type_id',
        'otp',
        // 'user_portrait',
        // 'user_license',
        // 'user_car',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    // AccountStatus: ONE TO MANY (naming convention: Plural, camelCase)
    public function accountStatuses(): HasMany
    {
        return $this->hasMany(AccountStatus::class);
    }
    // AccountStatus: ONE TO MANY (naming convention: Plural, camelCase)
    public function lastStatus(): HasOne
    {
        return $this->hasOne(AccountStatus::class)->latest();
    }

    // Wallet: ONE TO ONE (naming convention: Singular, camelCase)
    public function wallet(): HasOne
    {
        return $this->hasOne(Wallet::class);
    }

    // AccountInformation: ONE TO ONE (naming convention: Singular, camelCase)
    public function accountInformation(): HasOne
    {
        return $this->hasOne(AccountInformation::class);
    }

    // Tickets: ONE TO MANY (naming convention: Plural, camelCase)
    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    // UserType: MANY TO ONE (naming convention: Singular, camelCase)
    public function userType(): BelongsTo
    {
        return $this->belongsTo(UserType::class);
    }

    // Orders: ONE TO MANY (naming convention: Plural, camelCase)
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    // Tickets: ONE TO MANY (naming convention: Plural, camelCase)
    public function attachments(): HasMany
    {
        return $this->hasMany(Attachment::class);
    }
}
