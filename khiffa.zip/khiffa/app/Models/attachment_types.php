<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class attachment_types extends Model
{
    use HasFactory;

    public function attachment(): HasMany
    {
        return $this->HasMany(attachment::class);
    }
}
