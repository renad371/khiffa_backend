<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Wallet extends Model
{
    use HasFactory;
    
    protected $fillable = [
       
        'amount',
        'user_id',
       
    ];
    // Transaction: ONE TO MANY (naming convention: Plural, camelCase)
    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class);
    }

    // User: ONE TO ONE (naming convention: Singular, camelCase)
    public function user(): HasOne
    {
        return $this->hasOne(User::class);
    }
}
