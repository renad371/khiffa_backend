<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    use HasFactory;
    protected $fillable = [
        //beneficiary
        'beneficiary_name',
        'phone_number',
        //company
        'company_token',
        //beneficiary address
        'city',
        'district',
        'address_type_id',
        //order
        'khiffa_id',
        'delivery_cost',
        'distance',
        'company_id',
        'service_provider_id',
        'user_id',
        'receipt_id',
        'beneficiary_id',
        'address_id',
    ];

    // OrderStatus: ONE TO MANY (naming convention: Plural, camelCase)
    public function orderStatuses(): HasMany
    {
        return $this->hasMany(OrderStatus::class);
    }

    public function lastStatus(): HasOne
    {
        return $this->hasOne(OrderStatus::class)->latest();
    }

    // Receipt: ONE TO ONE (naming convention: Singular, camelCase)
    public function receipt(): HasOne
    {
        return $this->hasOne(Receipt::class);
    }

    // Company: MANY TO ONE (naming convention: Singular, camelCase)
    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    // Address: ONE TO ONE (naming convention: Singular, camelCase)
    public function address(): BelongsTo
    {
        return $this->belongsTo(Address::class);
    }

    // ServiceProvider: MANY TO ONE (naming convention: Singular, camelCase)
    public function serviceProvider(): BelongsTo
    {
        return $this->belongsTo(ServiceProvider::class);
    }

    // Location: ONE TO MANY (naming convention: Plural, camelCase)
    public function locations(): HasMany
    {
        return $this->hasMany(Location::class);
    }

    // Beneficiary: MANY TO ONE (naming convention: Singular, camelCase)
    public function beneficiary(): BelongsTo
    {
        return $this->belongsTo(Beneficiary::class);
    }

    // User: MANY TO ONE (naming convention: Singular, camelCase)
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
