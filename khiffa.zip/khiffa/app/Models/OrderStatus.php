<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderStatus extends Model
{
    use HasFactory;

    protected $fillable = [
        'status_id',
        'order_id',
    ];

    // status: MANY TO ONE (naming convention: Singular, camelCase)
    public function status(): BelongsTo
    {
        return $this->belongsTo(Status::class);
    }

    // order: MANY TO ONE (naming convention: Singular, camelCase)
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }
}
