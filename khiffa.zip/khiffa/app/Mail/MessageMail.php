<?php

namespace App\Mail;

use App\Http\Resources\AccountInformationResource;
use App\Models\AccountInformation;
use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class MessageMail extends Mailable
{
    use Queueable, SerializesModels;
    public $info;
  
    
    /**
     * Create a new message instance.
     *
     * @return void
     */
    
    public function __construct( $info)
    {
        $this->info=$info;
       
    }

   public function build()
    {
     // dd($this->user);
        $info=AccountInformation::where('name',$this->info->name)->first();
      //  dd($info);
    return $this->view("mail.MessageMail1")->with(['name' => $info->name]);


  }
//  mail.OtpMail
// public function  content(): Content{
        
     //  return new Content(
     //   markdown:'OtpMail',
        
      // with:
       //    ['otp'=>$this->user->otp]);
    //}
}
